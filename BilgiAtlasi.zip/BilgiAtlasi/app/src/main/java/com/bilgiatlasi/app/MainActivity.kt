package com.bilgiatlasi.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.net.URLEncoder
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

val Accents = listOf(
    "Deniz" to Color(0xFF0F8B8D),
    "Kehribar" to Color(0xFFD98E04),
    "Bordo" to Color(0xFF9E2A2B),
    "Çivit" to Color(0xFF3F51B5),
)

@Composable
fun App() {
    val prefs = LocalContext.current.getSharedPreferences("ayarlar", Context.MODE_PRIVATE)
    var mode by remember { mutableIntStateOf(prefs.getInt("mode", 0)) }
    var accent by remember { mutableIntStateOf(prefs.getInt("accent", 0)) }
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val c = Accents[accent].second
    val scheme = if (dark) darkColorScheme(primary = c, tertiary = c, secondaryContainer = c.copy(alpha = .35f))
    else lightColorScheme(primary = c, tertiary = c, secondaryContainer = c.copy(alpha = .22f))
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Root(
                mode, accent,
                { mode = it; prefs.edit().putInt("mode", it).apply() },
                { accent = it; prefs.edit().putInt("accent", it).apply() },
            )
        }
    }
}

@Composable
fun Root(mode: Int, accent: Int, setMode: (Int) -> Unit, setAccent: (Int) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var cat by remember { mutableStateOf<Cat?>(null) }
    var entry by remember { mutableStateOf<Entry?>(null) }
    BackHandler(entry != null || cat != null) { if (entry != null) entry = null else cat = null }

    val e = entry
    if (e != null) { Detail(e) { entry = null }; return }

    Scaffold(bottomBar = {
        NavigationBar {
            listOf("🧭" to "Keşfet", "🗂️" to "Kategoriler", "⚙️" to "Ayarlar").forEachIndexed { i, (icon, label) ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i; cat = null },
                    icon = { Text(icon, fontSize = 20.sp) },
                    label = { Text(label) },
                )
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            val c = cat
            when {
                tab == 0 -> Explore { entry = it }
                tab == 1 && c != null -> CategoryPage(c, { cat = null }) { entry = it }
                tab == 1 -> Categories { cat = it }
                else -> SettingsPage(mode, accent, setMode, setAccent)
            }
        }
    }
}

@Composable
fun WikiImage(wiki: String, emoji: String, modifier: Modifier) {
    val url by produceState<String?>(null, wiki) { value = Wiki.image(wiki) }
    val ctx = LocalContext.current
    Box(
        modifier.background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary.copy(alpha = .5f)))),
        contentAlignment = Alignment.Center,
    ) {
        Text(emoji, fontSize = 40.sp)
        url?.let {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(it).addHeader("User-Agent", "BilgiAtlasi/1.0").crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
            )
        }
    }
}

@Composable
fun EntryCard(e: Entry, open: (Entry) -> Unit, big: Boolean = false) {
    Card(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable { open(e) }) {
        WikiImage(e.info.wiki, e.cat.emoji, Modifier.fillMaxWidth().height(if (big) 210.dp else 140.dp))
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${e.cat.emoji} ${e.cat.name}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text(e.info.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(e.info.text, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun Explore(open: (Entry) -> Unit) {
    var q by remember { mutableStateOf("") }
    val daily = Entries[LocalDate.now().dayOfYear % Entries.size]
    val list = Entries.filter { q.isBlank() || it.info.title.contains(q, true) || it.info.text.contains(q, true) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Keşfet", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    placeholder = { Text("Bilgi ara") }, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                )
            }
        }
        if (q.isBlank()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Günün bilgisi", style = MaterialTheme.typography.titleMedium)
                    EntryCard(daily, open, big = true)
                    Text("Tüm bilgiler", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        items(list) { EntryCard(it, open) }
        if (list.isEmpty()) item { Text("Sonuç bulunamadı. Başka bir kelime dene.") }
    }
}

@Composable
fun Categories(open: (Cat) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp).padding(top = 16.dp)) {
        Text("Kategoriler", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        LazyVerticalGrid(
            GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
        ) {
            items(Cats) { c ->
                Card(Modifier.clip(RoundedCornerShape(20.dp)).clickable { open(c) }) {
                    WikiImage(c.items[0].wiki, c.emoji, Modifier.fillMaxWidth().height(110.dp))
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${c.emoji} ${c.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("${c.items.size} bilgi", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(c.desc, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryPage(c: Cat, back: () -> Unit, open: (Entry) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(back) { Text("← Kategoriler") }
                Text("${c.emoji} ${c.name}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text(c.desc, style = MaterialTheme.typography.bodyLarge)
            }
        }
        items(c.items) { EntryCard(Entry(it, c), open) }
    }
}

@Composable
fun Detail(e: Entry, back: () -> Unit) {
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box {
            WikiImage(e.info.wiki, e.cat.emoji, Modifier.fillMaxWidth().height(300.dp))
            FilledTonalButton(back, Modifier.statusBarsPadding().padding(12.dp)) { Text("← Geri") }
        }
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${e.cat.emoji} ${e.cat.name}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(e.info.title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(e.info.text, style = MaterialTheme.typography.bodyLarge, lineHeight = 26.sp)
            Button({ uri.openUri("https://tr.wikipedia.org/w/index.php?search=" + URLEncoder.encode(e.info.title, "UTF-8")) }) {
                Text("Wikipedia'da oku")
            }
            Spacer(Modifier.navigationBarsPadding())
        }
    }
}

@Composable
fun SettingsPage(mode: Int, accent: Int, setMode: (Int) -> Unit, setAccent: (Int) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Ayarlar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Tema", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Sistem", "Açık", "Koyu").forEachIndexed { i, n ->
                FilterChip(selected = mode == i, onClick = { setMode(i) }, label = { Text(n) })
            }
        }
        Text("Vurgu rengi", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Accents.forEachIndexed { i, (_, col) ->
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(col)
                        .then(if (accent == i) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                        .clickable { setAccent(i) }
                )
            }
        }
        HorizontalDivider()
        Text("Credits", style = MaterialTheme.typography.titleMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Bilgi Atlası  v1.0", fontWeight = FontWeight.Bold)
                Text("Elyionn ve Shephard tarafından yapılmıştır.")
                Text("Görseller: Wikipedia / Wikimedia Commons, ilgili lisanslarıyla.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
