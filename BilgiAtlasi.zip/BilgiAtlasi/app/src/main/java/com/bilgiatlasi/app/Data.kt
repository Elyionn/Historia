package com.bilgiatlasi.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** wiki = İngilizce Wikipedia sayfa başlığı; görsel buradan otomatik çekilir. */
data class Info(val title: String, val text: String, val wiki: String)
data class Cat(val name: String, val emoji: String, val desc: String, val items: List<Info>)
data class Entry(val info: Info, val cat: Cat)

val Cats = listOf(
    Cat("Tarih", "🏛️", "İmparatorluklar, devrimler ve savaşlar", listOf(
        Info("Roma İmparatorluğu", "MÖ 27'de Augustus ile imparatorluğa dönüşen Roma, Akdeniz çevresini yüzyıllarca ortak bir hukuk ve yol ağı altında birleştirdi. Batı Roma 476'da çöktü.", "Roman Empire"),
        Info("Fransız Devrimi", "1789'da başlayan devrim mutlak monarşiyi yıktı; özgürlük, eşitlik ve kardeşlik fikirlerini yaydı ve modern ulus-devlet anlayışını etkiledi.", "French Revolution"),
        Info("Osmanlı Devleti", "Yaklaşık 1299'da kuruldu, 1453'te İstanbul'un fethiyle yükselişe geçti ve 1922'de saltanatın kaldırılmasıyla sona erdi.", "Ottoman Empire"),
        Info("Sanayi Devrimi", "18. yüzyılın ikinci yarısında İngiltere'de buhar gücü ve fabrikalarla başladı; üretimi, şehirleşmeyi ve toplum yapısını kökten değiştirdi.", "Industrial Revolution"),
        Info("İkinci Dünya Savaşı", "1939–1945 arasında yaşanan, tarihin en ölümcül savaşı. Birleşmiş Milletler'i ve Soğuk Savaş dönemini doğuran yeni bir dünya düzeni bıraktı.", "World War II"),
        Info("İpek Yolu", "Çin'i Akdeniz'e bağlayan ticaret ağı. Mal kadar fikir, din ve teknolojinin de yayılmasını sağladı.", "Silk Road"),
    )),
    Cat("İdeoloji", "💡", "Devlet, birey ve toplum üzerine düşünce akımları", listOf(
        Info("Liberalizm", "Bireysel özgürlük, hukukun üstünlüğü ve sınırlı devlet fikrine dayanır; Aydınlanma çağında şekillendi.", "Liberalism"),
        Info("Sosyalizm", "Üretim araçlarının toplumsal denetimini ve ekonomik eşitliği savunan düşünce ailesi. 19. yüzyılda sanayi işçi hareketiyle güçlendi.", "Socialism"),
        Info("Muhafazakârlık", "Gelenek, toplumsal istikrar ve kademeli değişimi öne çıkarır. Edmund Burke'ün Fransız Devrimi eleştirisi sık sık kaynak gösterilir.", "Conservatism"),
        Info("Milliyetçilik", "Ulusun siyasal birliğin temeli olduğunu savunur; 19. yüzyılda Avrupa'da ulus-devletlerin doğuşunu hızlandırdı.", "Nationalism"),
        Info("Anarşizm", "Devlet otoritesinin gereksiz ve zararlı olduğunu savunur; gönüllü ve hiyerarşisiz örgütlenmeyi hedefler.", "Anarchism"),
        Info("Kapitalizm", "Üretim araçlarının özel mülkiyetine, piyasa rekabetine ve kâr amacına dayanan ekonomik sistem.", "Capitalism"),
    )),
    Cat("Jeopolitik", "🌍", "Coğrafyanın siyaseti ve gücü belirlemesi", listOf(
        Info("Soğuk Savaş", "1947–1991 arasında ABD ile Sovyetler Birliği arasındaki doğrudan çatışmaya dönüşmeyen küresel rekabet; silahlanma ve vekâlet savaşlarıyla belirginleşti.", "Cold War"),
        Info("Türk Boğazları", "İstanbul ve Çanakkale boğazları Karadeniz'i Akdeniz'e bağlar. Geçiş rejimi 1936 Montrö Sözleşmesi ile belirlenir.", "Turkish Straits"),
        Info("NATO", "1949'da kurulan askerî ittifak. Kuzey Atlantik Antlaşması'nın 5. maddesi ortak savunmayı düzenler.", "NATO"),
        Info("Kafkasya", "Karadeniz ile Hazar arasında, enerji koridorları ve etnik çeşitliliğiyle Rusya, Türkiye ve İran'ın etki alanlarının kesiştiği bölge.", "Caucasus"),
        Info("Hürmüz Boğazı", "Basra Körfezi'ni açık denizlere bağlayan dar geçit. Dünya petrol ticaretinin önemli bir bölümü buradan geçer.", "Strait of Hormuz"),
        Info("Avrupa Birliği", "Avrupa ülkelerinin ortak pazar ve kurumlar etrafında bütünleştiği siyasi ve ekonomik birlik. Kökleri 1950'lerdeki Kömür ve Çelik Topluluğu'na dayanır.", "European Union"),
    )),
    Cat("Dinler", "🕊️", "Dünya inanç sistemlerine genel bakış", listOf(
        Info("İslam", "7. yüzyılda Arap Yarımadası'nda ortaya çıkan, tek Tanrı inancına dayanan din. Kutsal kitabı Kur'an'dır.", "Islam"),
        Info("Hristiyanlık", "İsa'nın hayatı ve öğretisine dayanır; en çok mensubu olan dindir. Başlıca kolları Katoliklik, Ortodoksluk ve Protestanlıktır.", "Christianity"),
        Info("Yahudilik", "Tek Tanrı inancının en eski geleneklerinden biri. Tevrat ve Talmud merkezi metinlerdir.", "Judaism"),
        Info("Hinduizm", "Hindistan alt kıtasında köklenen, çok çeşitli inanç ve uygulamalardan oluşur; karma ve yeniden doğuş fikirleriyle bilinir.", "Hinduism"),
        Info("Budizm", "MÖ 5. yüzyıl civarında Siddhartha Gautama (Buda) ile ilişkilendirilen; acının sona ermesini ve aydınlanmayı hedefleyen öğreti.", "Buddhism"),
        Info("Sihizm", "15. yüzyılda Guru Nanak tarafından Pencap'ta kuruldu; tek Tanrı, eşitlik ve topluma hizmet vurgusu taşır.", "Sikhism"),
    )),
)

val Entries = Cats.flatMap { c -> c.items.map { Entry(it, c) } }

/** Wikipedia özet API'sinden sayfanın görsel adresini alır. */
object Wiki {
    private val cache = ConcurrentHashMap<String, String>()

    suspend fun image(title: String): String? = cache[title] ?: withContext(Dispatchers.IO) {
        runCatching {
            val t = URLEncoder.encode(title, "UTF-8").replace("+", "%20")
            val c = URL("https://en.wikipedia.org/api/rest_v1/page/summary/$t").openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "BilgiAtlasi/1.0 (GitHub project)")
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val json = c.inputStream.bufferedReader().use { it.readText() }
            JSONObject(json).optJSONObject("thumbnail")?.optString("source")?.also { cache[title] = it }
        }.getOrNull()
    }
}
