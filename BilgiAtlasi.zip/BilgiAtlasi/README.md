# Bilgi Atlası

Tarih, ideoloji, jeopolitik ve dinler hakkında Kotlin + Jetpack Compose ile yapılmış bilgi uygulaması.
Elyionn ve Shephard tarafından yapılmıştır.

## GitHub'da çalıştırma
1. Bu klasörü bir GitHub deposuna push et.
2. **Actions** sekmesinde "APK Derle" çalışır (veya elle başlat).
3. Bitince çıktıdaki **BilgiAtlasi-APK** dosyasını indir, telefona kurulum için `app-debug.apk`'yı aç.

Yeni bilgi eklemek için `Data.kt` içindeki `Cats` listesine `Info(başlık, metin, wikipediaBaşlığı)` ekle.
Görseller çalışma anında Wikipedia'dan çekilir (internet gerekir).
